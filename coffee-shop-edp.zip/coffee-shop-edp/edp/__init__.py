"""Event-driven coffee shop."""
